import { createContext } from "react"

export const baseUrl = "https://api.themoviedb.org/3"
export const imageUrl = "https://image.tmdb.org/t/p/original"
export const API_KEY = "c8e5cce4b12c4bdffdfb13395897da22"
export const navigateContext = createContext()